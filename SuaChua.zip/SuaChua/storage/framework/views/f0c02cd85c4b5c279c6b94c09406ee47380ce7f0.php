<?php
    $menu = menu('home_menu', '_json');
    // dd($menu);
?>
<header class="header header_menu clearfix">
    <div class="top_header" style="background-color: #024e98;">
        <div class="time_header">
            <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="clock" role="img"
                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-clock fa-w-16">
                <path fill="currentColor"
                    d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z"
                    class=""></path>
            </svg>
            <span>Thời gian làm việc: <?php echo e(setting('site.working_time')); ?></span>
        </div>
    </div>
    <div class="mid-header wid_100 clearfix">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-12 col-12">
                    <div class="menu-bar-mobile menu-bar-h nav-mobile-button">
                        <div class="menu-bar menubutton">
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1"
                                xmlns:xlink="http://www.w3.org/1999/xlink" width="23" height="23" x="0" y="0"
                                viewBox="0 0 384 384" style="enable-background:new 0 0 512 512" xml:space="preserve"
                                class="">
                                <g>
                                    <path xmlns="http://www.w3.org/2000/svg"
                                        d="m368 154.667969h-352c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h352c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"
                                        fill="#797979" data-original="#000000" style="" class=""></path>
                                    <path xmlns="http://www.w3.org/2000/svg"
                                        d="m368 32h-352c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h352c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"
                                        fill="#797979" data-original="#000000" style="" class=""></path>
                                    <path xmlns="http://www.w3.org/2000/svg"
                                        d="m368 277.332031h-352c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h352c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"
                                        fill="#797979" data-original="#000000" style="" class=""></path>
                                </g>
                            </svg>
                        </div>
                    </div>
                    <div class="logo_center">
                        <div class="logo">

                            <a href="<?php echo e(route('home')); ?>" class="logo-wrapper ">
                                <img src="<?php echo e(Voyager::image(setting('site.logo'))); ?>"
                                    alt="logo Template Dori">
                            </a>

                        </div>
                    </div>
                    <a class="cart-mobile-header" href="cart" title="Giỏ hàng">
                        <div class="icon-cart">
                            <svg width="26" height="25" viewBox="0 0 26 25" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M25.046 4.23271C25.0197 4.23271 24.9876 4.22681 24.9522 4.22032C24.9089 4.21237 24.8607 4.20352 24.8125 4.20352H6.42205L6.13014 2.24772C5.95499 0.963306 4.84573 0 3.53213 0H1.16764C0.52544 0 0 0.525439 0 1.16764C0 1.80985 0.52544 2.33529 1.16764 2.33529H3.53213C3.67808 2.33529 3.79485 2.45205 3.82404 2.59801L5.63389 14.9167C5.86742 16.4638 7.21021 17.6314 8.78653 17.6314H20.93C22.448 17.6314 23.7616 16.5514 24.0827 15.0626L25.9801 5.5755C26.0969 4.96249 25.6882 4.34948 25.046 4.23271ZM19.704 18.7115C18.0401 18.7115 16.6681 20.0543 16.6681 21.7474C16.6681 23.4113 18.0109 24.7833 19.704 24.7833C21.3679 24.7833 22.7399 23.4405 22.7399 21.7474C22.7107 20.0835 21.3679 18.7115 19.704 18.7115ZM9.25359 18.7115C10.8591 18.7115 12.2019 19.9959 12.2603 21.6014C12.3478 23.2653 11.0342 24.6665 9.37036 24.7541H9.31197C7.70646 24.7541 6.39286 23.4697 6.33448 21.8641C6.27609 20.2003 7.5605 18.7991 9.25359 18.7115Z"
                                    fill="#024E98" />
                            </svg>
                        </div>
                        <span class="count_item count_item_pr"></span>
                    </a>
                </div>
                <div class="col-xl-9 col-lg-9 col-12">
                    <div class="header-right">
                        <div class="header-bg">
                            <div class="cartgroup">
                                
                                
                                <div class="header_searchs">
                                    <div class="col-search-engine hidden-991">
                                        <div class="header_search">
                                            <form class="input-group search-bar"
                                                action="https://template-dori.mysapo.net/search" method="get"
                                                role="search">
                                                <input type="search" name="query" value=""
                                                    placeholder=""
                                                    class="input-group-field st-default-search-input search-text"
                                                    autocomplete="off" required>
                                                <span class="input-group-btn">
                                                    <button class="btn icon-fallback-text">
                                                        <img src="http://bizweb.dktcdn.net/100/425/159/themes/894862/assets/i-search.svg?1676275680316"
                                                            alt="Template Dori" />
                                                    </button>
                                                </span>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="heade_menunavs header-menu clearfix">
    <div class="container">
        <div class="header_search">
            <form class="input-group search-bar" action="https://template-dori.mysapo.net/search" method="get"
                role="search">
                <input type="search" name="query" value="" placeholder="Tìm kiếm sản phẩm" aria-label="search"
                    class="input-group-field st-default-search-input search-text" autocomplete="off" required>
                <span class="input-group-btn">
                    <button class="btn icon-fallback-text" aria-label="search">
                        <svg width="15" height="15" aria-hidden="true" focusable="false" data-prefix="fas"
                            data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                            class="svg-inline--fa fa-search fa-w-16">
                            <path fill="currentColor"
                                d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"
                                class=""></path>
                        </svg>
                    </button>
                </span>
            </form>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-mega hidden-sm hidden-xs">
                <div class="menu_mega">
                    
                </div>
            </div>

            <div class="col-lg-9 col-md-9 no-padding-left">
                <div class="right_content">
                    <div class="bg-header-nav">
                        <nav class="header-nav">
                            <ul class="item_big">

                                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item <?php if($item->url == "/".request()->segment(1)): ?> active <?php endif; ?> ">
                                    <a class="a-img" href="<?php echo e(asset($item->url)); ?>" title="<?php echo e($item->title); ?>">
                                        <span><?php echo e($item->title); ?></span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </nav>
                    </div>
                    <div class="phone_header">
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="menu-overlay" class=""></div>
<div class="wrapmenu_right_2 d-lg">
    <div class="wrapmenu">
        <div class="wrapmenu_full menumain_full">
            <div class="containers">
                <!-- Menu mobile -->
              
                <div class="menu_mobile_2">
                    <ul class="ul_collections">

                        <li class="level0 level-top parent">
                            <a href="<?php echo e(route('home')); ?>">Trang chủ</a>

                        </li>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="level0 level-top parent <?php if($item->url == "/".request()->segment(1)): ?> active <?php endif; ?> ">
                            <a class="a-img" href="<?php echo e(asset($item->url)); ?>" title="<?php echo e($item->title); ?>">
                                <span><?php echo e($item->title); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                    </ul>
                </div>
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\SuaChua\resources\views/frontend/layouts/partials/header.blade.php ENDPATH**/ ?>